# Bharat_intern-Task-2-Weather_Website
Repo for Bharat Intern Internship | Task 2 - Weather Website




Weather Website using HTML,CSS and Java Script
